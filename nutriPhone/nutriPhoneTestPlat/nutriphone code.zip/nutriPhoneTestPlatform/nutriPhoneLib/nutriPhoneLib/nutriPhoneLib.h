//
//  nutriPhoneLib.h
//  nutriPhoneLib
//
//  Created by NutriPhone on 10/2/14.
//  Copyright (c) 2014 EricksonLab. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for nutriPhoneLib.
FOUNDATION_EXPORT double nutriPhoneLibVersionNumber;

//! Project version string for nutriPhoneLib.
FOUNDATION_EXPORT const unsigned char nutriPhoneLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <nutriPhoneLib/PublicHeader.h>


